﻿namespace WebUsers
{
    public class Location
    {
        public string? City { get; set; }
        public string? State { get; set; }
        public string? Country { get; set; }
        public Street? Street { get; set; }

    }
}
