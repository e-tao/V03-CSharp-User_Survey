﻿namespace WebUsers
{
    public class Name
    {
        public string? First { get; set; }
        public string? Last { get; set; }
    }
}
