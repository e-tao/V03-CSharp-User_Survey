﻿namespace WebUsers
{
    public class Street
    {
        public int? Number { get; set; }
        public string? Name { get; set; }
    }
}
