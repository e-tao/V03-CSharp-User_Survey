﻿using System.Collections.ObjectModel;

namespace WebUsers
{
    public class Users
    {

        public ObservableCollection<User>? Results { get; set; }
    }
}
