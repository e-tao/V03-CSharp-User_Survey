﻿namespace WebUsers
{
    public class Picture
    {
        public string? Thumbnail { get; set; }
        public string? Medium { get; set; }
    }
}
