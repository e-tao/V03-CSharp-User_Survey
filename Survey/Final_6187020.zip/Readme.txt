1. for better data visualization, the "+" button can add 20ish, 50ish and 100ish random user and corresponding survey results.

2. if the added user doesn't complete the survey the user will be deleted right away, so there should be no invalid  survey results in the database.

3. user can only see the result after finish the survey or generate random results.
